package com.muscode.covid19stats.view.ui.country

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.blongho.country_data.World
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.muscode.covid19stats.R
import com.muscode.covid19stats.model.CovidSummary
import com.muscode.covid19stats.view.ui.country.fragments.CountryListFragment


class CountryListActivity : AppCompatActivity() {
    private lateinit var gson: Gson
    lateinit var countryList: List<CovidSummary>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_country_list)
        if (savedInstanceState == null) {
            gson = Gson()
            loadFlagsLib()
            countryList = getSummaryList()
            startListFragment(getSummaryList().toMutableList())
        }
    }

    private fun loadFlagsLib() = World.init(applicationContext)

    private fun getSummaryList(): List<CovidSummary> = gson.fromJson(
        intent?.extras?.get("countryList").toString(),
        object : TypeToken<List<CovidSummary>>() {}.type
    )

    private fun startListFragment(summaryList: MutableList<CovidSummary>) {
        supportFragmentManager
            .beginTransaction()
            .add(R.id.container, CountryListFragment(summaryList), "countryList")
            .commit()
    }
}