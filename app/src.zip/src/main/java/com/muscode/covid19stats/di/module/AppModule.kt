package com.muscode.covid19stats.di.module

import com.muscode.covid19stats.repository.remote.CovidSummaryRepository
import com.muscode.covid19stats.repository.remote.LocationRepository
import com.muscode.covid19stats.repository.remote.retrofit.CovidApi
import com.muscode.covid19stats.repository.remote.retrofit.LocationApi
import com.muscode.covid19stats.repository.remote.retrofit.RetrofitClientInstances.covidInstance
import com.muscode.covid19stats.repository.remote.retrofit.RetrofitClientInstances.locationInstance
import com.muscode.covid19stats.util.NetworkChecker
import org.koin.dsl.module

val appModule = module {
    single { NetworkChecker() }
    single { LocationRepository(get()) }
    single { CovidSummaryRepository(get()) }
    single {
        covidInstance()!!.create(
            CovidApi::class.java
        )
    }
    single {
        locationInstance()!!.create(
            LocationApi::class.java
        )
    }
}
