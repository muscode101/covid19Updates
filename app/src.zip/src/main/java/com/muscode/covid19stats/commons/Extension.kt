package com.muscode.covid19stats.commons

import com.muscode.covid19stats.model.Coordinates
import com.muscode.covid19stats.model.CovidSummary
import com.muscode.covid19stats.model.Stats

object Extension {

}