package com.muscode.covid19stats.view.ui.splash

import android.content.Intent
import android.os.Bundle
import android.view.Window
import androidx.appcompat.app.AppCompatActivity
import com.muscode.covid19stats.R
import com.muscode.covid19stats.view.ui.main.MainActivity
import kotlinx.android.synthetic.main.activity_splash.*
import kotlinx.coroutines.*
import org.jetbrains.anko.design.indefiniteSnackbar
import org.koin.android.viewmodel.ext.android.viewModel


class SplashActivity : AppCompatActivity() {

    private val viewModel: SplashViewModel by viewModel()
    private val activityScope = CoroutineScope(Dispatchers.Main)

    override fun onCreate(savedInstanceState: Bundle?) {
        removeSupportActionBar()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        startActivityWithNetwork()
    }

    private fun startActivityWithNetwork() {
        activityScope.launch {
            delay(3000)
            if (viewModel.isInternetAvailable()) {
                startMainActivity()
            } else {
                showSnackBar()
            }
        }
    }

    private fun removeSupportActionBar() {
        window.requestFeature(Window.FEATURE_ACTION_BAR)
        supportActionBar!!.hide()
    }

    private fun showSnackBar() {
        ll_splash.indefiniteSnackbar(
            "Check your internet connection",
            "try again"
        ) {
            activityScope.launch {
                if (viewModel.isInternetAvailable()) {
                    startMainActivity()
                } else {
                    showSnackBar()
                }
            }
        }
    }

    private fun startMainActivity() {
        startActivity(Intent(this@SplashActivity, MainActivity::class.java))
        finish()
    }

    override fun onPause() {
        super.onPause()
        activityScope.cancel()
    }
}