package com.muscode.covid19stats.view.ui.country.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SearchView
import androidx.fragment.app.Fragment
import com.muscode.covid19stats.R
import com.muscode.covid19stats.model.CovidSummary
import com.muscode.covid19stats.view.adapter.Adapter
import kotlinx.android.synthetic.main.fragment_item_list.view.*

class CountryListFragment(private val summaryList: MutableList<CovidSummary>) : Fragment() {

    private lateinit var rv: View
    private lateinit var adapter: Adapter


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        rv = inflater.inflate(
            R.layout.fragment_item_list,
            container, false
        )

        countryArrayList = summaryList as ArrayList<CovidSummary>

        initRecyclerView()
        initRecyclerViewSearch()
        getClickedItem()

        return rv
    }

    private fun initRecyclerViewSearch() {
        rv.search.maxWidth = Int.MAX_VALUE
        rv.search.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                adapter.filter(query!!)
                return false
            }

            override fun onQueryTextChange(query: String?): Boolean {
                adapter.filter(query!!)
                return false
            }
        })
    }

    private fun initRecyclerView() {
        adapter = Adapter()
        adapter.setCountryList(countryArrayList!!)
        rv.rv_list.adapter = adapter
    }

    companion object {
        var countryArrayList: ArrayList<CovidSummary>? =
            null
    }

    private fun getClickedItem() {
//        Adapter{ item -> doClick(item) }
    }
}