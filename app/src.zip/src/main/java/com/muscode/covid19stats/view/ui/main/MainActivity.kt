package com.muscode.covid19stats.view.ui.main


import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.blongho.country_data.World
import com.google.gson.Gson
import com.muscode.covid19stats.R
import com.muscode.covid19stats.model.Stats
import com.muscode.covid19stats.model.activeCases
import com.muscode.covid19stats.view.ui.country.CountryListActivity
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.content_main.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import org.koin.android.viewmodel.ext.android.viewModel

class MainActivity : AppCompatActivity() {

    private val viewModel: MainViewModel by viewModel()
    private val activityScope = CoroutineScope(Dispatchers.Main)



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(toolbar)

        loadFlagsLib()
        getCurrentCountryStats()

        btn_all_countries.setOnClickListener {
            startListActivity()
        }
    }

    override fun onPause() {
        super.onPause()
        activityScope.cancel()
    }

    private fun loadFlagsLib() = World.init(applicationContext)

    private fun setFlag(countryName: String) =
        iv_flag.setImageResource(World.getFlagOf(countryName))

    private fun getCurrentCountryStats() {
        var stats: Stats
        activityScope.launch {
            setFlag(viewModel.getLocation())
            stats = viewModel.getCurrentCountrySummary().stats
            tv_active.text = stats.activeCases
            tv_cases.text = stats.confirmed.toString()
            tv_deaths.text = stats.deaths.toString()
            tv_recovered.text = stats.recovered.toString()

        }
    }

    private fun startListActivity() {
        val i = Intent(this, CountryListActivity::class.java)
        val gson = Gson()
        activityScope.launch {
            viewModel.getCovidSummary()
            i.putExtra("countryList", gson.toJson(viewModel.getCovidSummary()))
            startActivity(i)
        }
    }
}
