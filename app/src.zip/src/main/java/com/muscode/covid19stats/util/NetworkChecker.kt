package com.muscode.covid19stats.util

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket

class NetworkChecker {

    suspend fun isOnline(): Boolean =
        coroutineScope {
            return@coroutineScope withContext(Dispatchers.Default) { tryToPing() }
        }

    private fun tryToPing(): Boolean =
        try {
            ping()
            true
        } catch (e: IOException) {
            false
        }

    private fun ping() {
        val sock = Socket()
        sock.connect(InetSocketAddress("8.8.8.8", 53), 1500)
        sock.close()
    }
}