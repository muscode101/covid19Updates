package com.muscode.covid19stats.model


val Stats.activeCases: CharSequence?
	get() = confirmed.minus((deaths + recovered))
		.toString()

data class Stats (

	val confirmed : Int,
	val deaths : Int,
	val recovered : Int
)