package com.muscode.covid19stats.model

data class CovidSummary(
    val country: String,
    val province: String,
    val updatedAt: String,
    val stats: Stats,
    val coordinates: Coordinates
){
	companion object{
		fun emptySummaryCovidSummary()
				= CovidSummary(
			"", "", "",
			Stats(0, 0, 0),
			Coordinates("", "")
		)
	}
}