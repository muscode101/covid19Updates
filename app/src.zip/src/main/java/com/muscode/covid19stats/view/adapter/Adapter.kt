package com.muscode.covid19stats.view.adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.blongho.country_data.World
import com.muscode.covid19stats.R
import com.muscode.covid19stats.model.CovidSummary
import com.muscode.covid19stats.model.activeCases
import com.muscode.covid19stats.view.ui.country.fragments.CountryListFragment
import kotlinx.android.extensions.LayoutContainer
import kotlinx.android.synthetic.main.fragment_item.*
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.ConflatedBroadcastChannel
import java.util.*

class Adapter : RecyclerView.Adapter<Adapter.ViewHolder>() {

    @ExperimentalCoroutinesApi
    private val channel = ConflatedBroadcastChannel<CovidSummary>()
    private val countryList: ArrayList<CovidSummary> = ArrayList()
    private lateinit var countryArrayList: ArrayList<CovidSummary>


    fun setCountryList(dataList: ArrayList<CovidSummary>) {
        countryArrayList = dataList
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.fragment_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val country = countryArrayList[position].country
        val countrySummary = countryArrayList[position]
        val stats = countryArrayList[position].stats


        holder.tv_country.text = country
        holder.tv_active.text = stats.activeCases
        holder.tv_cases.text = stats.confirmed.toString()
        holder.tv_deaths.text = stats.deaths.toString()
        holder.tv_recovered.text = stats.recovered.toString()

        holder.card.setOnClickListener {

//            setCountryItem(countrySummary)
        }
        setImageFlag(holder, country.toLowerCase(Locale.getDefault()))
    }

    @ExperimentalCoroutinesApi
    suspend fun setCountryItem(countrySummary: CovidSummary) {
        coroutineScope {
            withContext(Dispatchers.Default) {
                channel.send(countrySummary)
            }
        }
    }

    private fun setImageFlag(holder: Adapter.ViewHolder, countryCode: String) {
        try {
            val flag = World.getFlagOf(countryCode)
            holder.iv_flag.setImageResource(flag)
        } catch (e: Exception) {
            Log.d("adapter", e.message.toString())
        }
    }

    override fun getItemCount(): Int {
        return countryArrayList.size
    }

    fun filter(charText: String) {
        val lowerCaseText = charText.toLowerCase(Locale.getDefault())
        CountryListFragment.countryArrayList!!.clear()
        if (lowerCaseText.isEmpty()) {
            CountryListFragment.countryArrayList!!.addAll(countryList)
        } else {
            for (country in countryList) {
                if (country.country.toLowerCase(Locale.getDefault()).contains(lowerCaseText)) {
                    CountryListFragment.countryArrayList!!.add(country)
                }
            }
        }
        notifyDataSetChanged()
    }

    init {
        countryList.addAll(CountryListFragment.countryArrayList!!)
    }

    inner class ViewHolder(override val containerView: View) :
        RecyclerView.ViewHolder(containerView), LayoutContainer
}