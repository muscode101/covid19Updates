package com.muscode.covid19stats.repository.remote

import com.muscode.covid19stats.model.DeviceLocation
import com.muscode.covid19stats.repository.remote.retrofit.LocationApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext

class LocationRepository(private val deviceLocationApi: LocationApi) {

    suspend fun getLocation(): DeviceLocation =
        coroutineScope {
            withContext(Dispatchers.Default) {
                deviceLocationApi.getDeviceLocation()
            }
        }
}