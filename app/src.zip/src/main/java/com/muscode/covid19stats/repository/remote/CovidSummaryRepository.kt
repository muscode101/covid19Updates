package com.muscode.covid19stats.repository.remote

import com.muscode.covid19stats.model.CovidSummary
import com.muscode.covid19stats.repository.remote.retrofit.CovidApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext

class CovidSummaryRepository(private val covidSummaryApi: CovidApi) {

    suspend fun getSummary(): List<CovidSummary> =
        coroutineScope {
            withContext(Dispatchers.Default) {
                covidSummaryApi.getCovidSummary()
            }
        }
}