package com.muscode.covid19stats.repository.remote.retrofit

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitClientInstances {
    private var retrofitCovid: Retrofit? = null
    private var retrofitLocation: Retrofit? = null
    private const val covid19BaseUrl = "http://corona.lmao.ninja"
    private const val locationBaseUrl = "http://ip-api.com"

    fun covidInstance(): Retrofit? {
        if (retrofitCovid == null) {
            retrofitCovid = Retrofit.Builder()
                .baseUrl(covid19BaseUrl)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
        }
        return retrofitCovid
    }

    fun locationInstance(): Retrofit? {
        if (retrofitLocation == null) {
            retrofitLocation = Retrofit.Builder()
                .baseUrl(locationBaseUrl)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
        }
        return retrofitLocation
    }
}