package com.muscode.covid19stats.view.ui.splash

import androidx.lifecycle.ViewModel
import com.muscode.covid19stats.util.NetworkChecker

class SplashViewModel(private val networkChecker: NetworkChecker) : ViewModel() {

    suspend fun isInternetAvailable(): Boolean =
        networkChecker.isOnline()

}