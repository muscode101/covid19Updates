package com.muscode.covid19stats.model

import com.google.gson.annotations.SerializedName

data class DeviceLocation (

    @SerializedName("status") val status : String,
    @SerializedName("country") val country : String,
    @SerializedName("countryCode") val countryCode : String,
    @SerializedName("region") val region : Int,
    @SerializedName("regionName") val regionName : String,
    @SerializedName("city") val city : String,
    @SerializedName("zip") val zip : String,
    @SerializedName("lat") val lat : Double,
    @SerializedName("lon") val lon : Double,
    @SerializedName("timezone") val timezone : String,
    @SerializedName("isp") val isp : String,
    @SerializedName("org") val org : String,
    @SerializedName("as") val AS : String,
    @SerializedName("query") val query : String
)