package com.muscode.covid19stats.model

data class Coordinates(
    val latitude: String,
    val longitude: String
)