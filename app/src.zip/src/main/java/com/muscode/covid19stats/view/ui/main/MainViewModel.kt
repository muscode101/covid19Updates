package com.muscode.covid19stats.view.ui.main

import androidx.lifecycle.ViewModel
import com.muscode.covid19stats.model.CovidSummary
import com.muscode.covid19stats.repository.remote.CovidSummaryRepository
import com.muscode.covid19stats.repository.remote.LocationRepository

class MainViewModel(
    private val locationRepository: LocationRepository,
    private val covidSummaryRepository: CovidSummaryRepository
) : ViewModel() {

    suspend fun getLocation(): String =
        locationRepository.getLocation().country

    suspend fun getCovidSummary(): List<CovidSummary> =
        covidSummaryRepository.getSummary()

    suspend fun getCurrentCountrySummary(): CovidSummary {
        val location = getLocation()
        val covidList = getCovidSummary()
        var covidSummary = CovidSummary.emptySummaryCovidSummary()
        covidList.forEach { summary ->
            if (summary.country == location) {
                covidSummary = summary
            }
        }
        return covidSummary
    }
}