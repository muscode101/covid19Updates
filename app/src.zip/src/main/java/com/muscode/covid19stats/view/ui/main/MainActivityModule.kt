package com.muscode.covid19stats.view.ui.main

import org.koin.dsl.module


val mainModule = module {
    single { MainViewModel(get(),get()) }
}